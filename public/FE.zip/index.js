const express = require('express');
const app = express();

app.use(express.json());

const validateHeaders = (req, res, next) => {
  const userId = req.header('User-id');
  const scope = req.header('Scope');

  if (userId !== 'ifabula' || scope !== 'user') {
    return res.status(401).json({
      responseCode: 401,
      responseMessage: 'UNAUTHORIZED',
    });
  }
  next();
};

// API GET - Mendapatkan data
app.get('/api/data', validateHeaders, (req, res) => {
  const data = {
    message: 'Ini adalah data dari API GET!',
    data: [1, 2, 3, 4, 5],
  };
  res.status(200).json(data);
});

app.post('/api/data', validateHeaders, (req, res) => {
  const { name, age } = req.body;

  if (!name || !age) {
    return res.status(400).json({
      responseCode: 400,
      responseMessage: 'Nama dan usia harus diisi!',
    });
  }

  const responseData = {
    message: 'Data berhasil diterima.',
    receivedData: {
      name: name,
      age: age,
    },
  };
  res.status(201).json(responseData);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server berjalan di Port ${PORT}`);
});
